const { app, BrowserWindow, Menu } = require('electron');

// ⚠️ Remplace cette URL par celle de ton site une fois hébergé sur Render
const AFRIVERSE_URL = 'https://romaric123.pythonanywhere.com';

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    title: 'AfriVerse',
    icon: __dirname + '/assets/icon.png',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  Menu.setApplicationMenu(null); // enlève la barre de menu par défaut, look plus "appli"
  win.loadURL(AFRIVERSE_URL);
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
