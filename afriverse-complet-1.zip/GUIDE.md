# Guide AfriVerse — De ton zip à des vraies applis installables

Tu n'auras qu'**une seule chose à faire toi-même** : héberger le serveur en ligne (10 minutes).
Tout le reste (fabriquer les applis mobile/ordi) est déjà préparé — il suffit de suivre les étapes.

## Structure livrée

```
afriverse-server/     → ton site Flask, prêt pour l'hébergement gratuit (Render)
afriverse-mobile/     → projet Capacitor → génère l'app Android (.apk) et iOS
afriverse-desktop/    → projet Electron → génère l'app Windows (.exe) et Mac (.dmg)
GUIDE.md              → ce fichier
```

---

## Étape 1 — Héberger le serveur (LA SEULE CHOSE QUE TU DOIS FAIRE)

1. Crée un compte gratuit sur https://github.com et sur https://render.com
2. Sur GitHub : crée un nouveau dépôt, mets-y le contenu du dossier `afriverse-server/`
3. Sur Render : "New +" → "Web Service" → connecte ton dépôt GitHub
4. Render détecte le `Procfile` automatiquement. Renseigne :
   - Build command : `pip install -r requirements.txt`
   - Start command : `gunicorn app:app`
5. Clique "Create Web Service". Après 2-3 minutes, Render te donne une URL du type :
   `https://afriverse-xxxx.onrender.com`

**Note cette URL — c'est tout ce dont j'ai besoin ensuite.**

⚠️ Pense à définir une vraie clé secrète dans les variables d'environnement Render :
`SECRET_KEY` = une longue chaîne aléatoire (pas celle du code, qui est juste pour tester en local).

---

## Étape 2 — Brancher les applis sur ton URL

Une fois que tu as ton URL Render, envoie-la moi et je remplace automatiquement
`REMPLACE-PAR-TON-URL-RENDER.onrender.com` dans :
- `afriverse-mobile/capacitor.config.json`
- `afriverse-desktop/main.js`

(Tu peux aussi le faire toi-même : cherche-remplace dans ces 2 fichiers.)

---

## Étape 3 — Générer l'appli mobile (.apk) SANS RIEN INSTALLER (PC modeste, 4 Go RAM)

Comme ton PC (Dell Latitude, 4 Go RAM) n'a pas assez de mémoire pour Android Studio,
on fabrique l'`.apk` gratuitement sur les ordinateurs de GitHub (GitHub Actions),
pas sur le tien.

1. Crée un compte gratuit sur https://github.com (juste email + mot de passe, pas de carte).
2. Crée un nouveau dépôt (bouton vert "New").
3. Mets-y **tout le contenu de ce zip** (dossiers `afriverse-server`, `afriverse-mobile`,
   `afriverse-desktop`, `.github` inclus) — tu peux les glisser-déposer directement sur
   la page GitHub via "Add file → Upload files", pas besoin de terminal.
4. Une fois envoyé, va dans l'onglet **"Actions"** en haut du dépôt.
5. Le workflow "Build APK Android" se lance tout seul (ça prend 3-5 minutes).
6. Une fois terminé (coche verte ✅), clique dessus, puis descends jusqu'à
   **"Artifacts"** → clique sur "afriverse-apk" pour télécharger le fichier `.apk`.

C'est ce fichier `.apk` que tu distribues. Zéro installation sur ton PC.

---

## Étape 4 — Générer l'appli ordinateur (.exe) de la même façon

Même principe, aucune installation chez toi :

1. Dans le même dépôt GitHub, va dans l'onglet **"Actions"**.
2. Le workflow "Build EXE Windows" se lance automatiquement aussi.
3. Une fois terminé, clique dessus → **"Artifacts"** → "afriverse-exe" → télécharge le `.exe`.

(Pour un `.dmg` Mac, il faudrait remplacer `runs-on: windows-latest` par `macos-latest`
dans `.github/workflows/build-desktop.yml` — dis-le moi si tu veux aussi une version Mac.)

---

## Étape 5 — Icônes (optionnel mais recommandé)

Le dossier `afriverse-desktop/assets/` contient des instructions pour transformer ton logo
en icônes `.ico` / `.icns` / `.png`. Sans ça, une icône par défaut sera utilisée.

---

## Ce que les utilisateurs finaux reçoivent

- **Mobile** : un fichier `.apk` à installer (ou plus tard, l'appli sur le Play Store)
- **Ordinateur** : un fichier `.exe` (Windows) ou `.dmg` (Mac) à installer
- Ils n'ont **jamais** accès à ton code, ta base de données, ni ton dossier `afriverse-server/`.
  Seul toi héberges le serveur et gères les fichiers sources.

---

## Et après ?

Une fois que tu as testé toi-même et que ça marche bien, la prochaine étape logique
(quand tu auras des retours d'utilisateurs) sera de passer en Option B : une vraie
interface Flutter connectée à l'API JSON déjà présente dans ton code (`api/`), pour
une appli plus rapide et publiable officiellement sur les stores.
